# Personal Expense Tracker Backend

A production-ready backend service for tracking personal monthly expenses built with Node.js, Express, TypeScript, and MongoDB.

## Features

✅ **User Management**
- Create users with name, email, and monthly budget
- Unique email validation
- User profile management

✅ **Expense Tracking**
- Add expenses with title, amount, category, and date
- Categorized expenses (Food, Travel, Shopping, Entertainment, Utilities, Healthcare, Education, Other)
- Expenses linked to specific users

✅ **Advanced Functionality**
- Monthly expense summary with category breakdown
- Remaining budget calculation
- Pagination and filtering for expenses
- Date range filtering
- Category-based filtering

✅ **Code Quality**
- TypeScript for type safety
- Clean architecture with separation of concerns
- Comprehensive error handling
- Request validation with Joi
- Security middleware (Helmet, CORS)
- Request logging with Morgan
- Mongoose hooks and middleware for data consistency

## Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Language**: TypeScript
- **Database**: MongoDB (Atlas)
- **ODM**: Mongoose
- **Validation**: Joi
- **Security**: Helmet, CORS
- **Logging**: Morgan

## Project Structure

```
backend/
├── src/
│   ├── config/
│   │   ├── database.ts         # MongoDB connection
│   │   └── env.ts              # Environment configuration
│   ├── controllers/
│   │   ├── userController.ts   # User request handlers
│   │   └── expenseController.ts# Expense request handlers
│   ├── middleware/
│   │   ├── errorHandler.ts     # Global error handling
│   │   ├── logger.ts           # Request logging
│   │   └── security.ts         # Security headers & CORS
│   ├── models/
│   │   ├── User.ts             # User schema with hooks
│   │   └── Expense.ts          # Expense schema with hooks
│   ├── routes/
│   │   ├── index.ts            # Route configuration
│   │   ├── userRoutes.ts       # User endpoints
│   │   ├── expenseRoutes.ts    # Expense endpoints
│   │   └── userExpenseRoutes.ts# Nested expense routes
│   ├── services/
│   │   ├── userService.ts      # User business logic
│   │   └── expenseService.ts   # Expense business logic
│   ├── types/
│   │   └── index.ts            # TypeScript interfaces
│   ├── utils/
│   │   ├── errors.ts           # Custom error classes
│   │   ├── response.ts         # Response formatters
│   │   ├── validators.ts       # Joi validation schemas
│   │   └── pagination.ts       # Pagination utilities
│   └── index.ts                # Server entry point
├── .env.example                # Environment template
├── tsconfig.json              # TypeScript configuration
├── package.json               # Dependencies
└── README.md                  # This file
```

## Setup Instructions

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- MongoDB Atlas account

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   ```

   Edit `.env` and add your MongoDB Atlas connection string:
   ```env
   NODE_ENV=development
   PORT=5000
   MONGODB_URI=mongodb+srv://username:password@cluster0.mongodb.net/expense-tracker?retryWrites=true&w=majority
   ```

### Database Setup

1. Create a MongoDB Atlas cluster:
   - Visit [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
   - Create a new cluster
   - Create a database user
   - Get your connection string

2. The application will automatically create collections on first run

### Running the Server

**Development mode (with hot reload)**
```bash
npm run dev
```

**Build for production**
```bash
npm run build
npm start
```

**Type checking**
```bash
npm run type-check
```

**Linting**
```bash
npm run lint
```

## API Documentation

### Base URL
```
http://localhost:5000/api/v1
```

### Response Format

All responses follow a consistent format:

**Success Response**
```json
{
  "success": true,
  "message": "Operation successful",
  "data": { ... },
  "statusCode": 200
}
```

**Error Response**
```json
{
  "success": false,
  "message": "Error message",
  "error": "Error details",
  "statusCode": 400
}
```

**Paginated Response**
```json
{
  "success": true,
  "message": "Data retrieved",
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 45,
    "pages": 5
  }
}
```

### Endpoints

#### Users

**Create User**
```
POST /api/v1/users
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "monthlyBudget": 5000
}

Response: 201 Created
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "monthlyBudget": 5000,
    "createdAt": "2024-01-15T10:30:00Z",
    "updatedAt": "2024-01-15T10:30:00Z"
  }
}
```

**Get User**
```
GET /api/v1/users/:id

Response: 200 OK
{
  "success": true,
  "message": "User retrieved successfully",
  "data": { ... }
}
```

**Get All Users**
```
GET /api/v1/users?page=1&limit=10

Response: 200 OK
{
  "success": true,
  "message": "Users retrieved successfully",
  "data": [...],
  "pagination": { ... }
}
```

**Update User**
```
PUT /api/v1/users/:id
Content-Type: application/json

{
  "monthlyBudget": 6000
}

Response: 200 OK
```

**Delete User**
```
DELETE /api/v1/users/:id

Response: 200 OK
{
  "success": true,
  "message": "User deleted successfully"
}
```

#### Expenses

**Create Expense**
```
POST /api/v1/expenses
Content-Type: application/json

{
  "userId": "507f1f77bcf86cd799439011",
  "title": "Lunch at restaurant",
  "amount": 25.50,
  "category": "Food",
  "date": "2024-01-15T12:00:00Z"
}

Response: 201 Created
{
  "success": true,
  "message": "Expense created successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439012",
    "userId": { ... },
    "title": "Lunch at restaurant",
    "amount": 25.50,
    "category": "Food",
    "date": "2024-01-15T12:00:00Z",
    "createdAt": "2024-01-15T10:30:00Z",
    "updatedAt": "2024-01-15T10:30:00Z"
  }
}
```

**Get Expense**
```
GET /api/v1/expenses/:id

Response: 200 OK
```

**Get User Expenses**
```
GET /api/v1/users/:userId/expenses?page=1&limit=10&category=Food&startDate=2024-01-01&endDate=2024-01-31

Query Parameters:
- page: number (default: 1)
- limit: number (default: 10, max: 100)
- category: string (optional)
- startDate: ISO date string (optional)
- endDate: ISO date string (optional)

Response: 200 OK
{
  "success": true,
  "message": "User expenses retrieved successfully",
  "data": [...],
  "pagination": { ... }
}
```

**Get Monthly Summary**
```
GET /api/v1/users/:userId/summary

Response: 200 OK
{
  "success": true,
  "message": "Expense summary retrieved successfully",
  "data": {
    "totalExpenses": 150.75,
    "remainingBudget": 4849.25,
    "expenseCount": 6,
    "monthlyBudget": 5000,
    "expensesByCategory": {
      "Food": 45.50,
      "Travel": 105.25
    }
  }
}
```

**Update Expense**
```
PUT /api/v1/expenses/:id
Content-Type: application/json

{
  "amount": 30.00,
  "title": "Updated title"
}

Response: 200 OK
```

**Delete Expense**
```
DELETE /api/v1/expenses/:id

Response: 200 OK
{
  "success": true,
  "message": "Expense deleted successfully"
}
```

## Validation Rules

### User Validation
- **name**: String, 2-100 characters, required
- **email**: Valid email format, unique, required
- **monthlyBudget**: Number > 0, required

### Expense Validation
- **userId**: Valid MongoDB ObjectId, must reference existing user, required
- **title**: String, 2-200 characters, required
- **amount**: Number > 0, required
- **category**: One of: Food, Travel, Shopping, Entertainment, Utilities, Healthcare, Education, Other
- **date**: ISO date string, cannot be future date, required

## Error Handling

The API returns appropriate HTTP status codes and error messages:

- **400 Bad Request**: Validation failed or invalid input
- **404 Not Found**: Resource not found
- **409 Conflict**: Email already exists
- **500 Internal Server Error**: Server error

All errors include a descriptive message to help with debugging.

## Middleware Architecture

### Security Middleware
- **Helmet**: Sets various HTTP headers for security
- **CORS**: Configured for cross-origin requests
- **Request Size Limit**: Prevents large payload attacks
- **Security Headers**: X-Content-Type-Options, X-Frame-Options, X-XSS-Protection

### Error Handling Middleware
- Catches all exceptions
- Handles MongoDB validation errors
- Handles MongoDB cast errors
- Handles duplicate key errors
- Returns consistent error responses

### Logging Middleware
- Logs all incoming requests
- Tracks response times
- Skips health check endpoint

## Mongoose Hooks

### User Model
- **Pre-save**: Validates email uniqueness
- **Index**: Unique index on email for database-level enforcement

### Expense Model
- **Pre-save**: Validates user exists
- **Pre-find**: Auto-populates user data
- **Indexes**: Optimized queries for userId, category, and date

## Database Hosting

The application uses MongoDB Atlas (cloud-hosted MongoDB):

1. **Create Account**: https://www.mongodb.com/cloud/atlas
2. **Create Cluster**: Free tier available
3. **Create Database User**: For authentication
4. **Whitelist IP**: Add your IP address to allow connections
5. **Get Connection String**: Use in .env file

Connection string format:
```
mongodb+srv://username:password@cluster.mongodb.net/database?retryWrites=true&w=majority
```

## Assumptions & Design Decisions

1. **No Authentication**: API endpoints are public for testing purposes. In production, add JWT auth.
2. **Monthly Summary**: Always calculates for current month (not user-specified month).
3. **Expense Population**: User details are auto-populated in expense responses.
4. **Date Validation**: Expense dates cannot be in the future.
5. **Budget Validation**: Monthly budget must be positive.
6. **Cascading Delete**: Deleting a user deletes all associated expenses.
7. **Pagination Default**: Page size defaults to 10, max 100.

## Git Commit History

The repository maintains clean, meaningful commit history:

- Initial setup and configuration
- Database schema and models
- Services layer implementation
- Controllers and request handlers
- Routes configuration
- Middleware setup
- Error handling and validation
- Documentation

View history with:
```bash
git log --oneline
```

## AI Tools Used

See `PROMPTS_USED.md` for details on AI assistance provided during development.

## License

ISC

## Support

For issues or questions, please check the error messages and logs for debugging information.
