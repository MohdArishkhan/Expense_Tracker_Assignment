# Quick Start Guide

Get the Personal Expense Tracker Backend running in 5 minutes.

## Prerequisites

- Node.js 16+ installed
- MongoDB Atlas account (free tier available)
- npm or yarn package manager

## Step 1: Clone & Install

```bash
# Clone repository
git clone <repository-url>
cd backend

# Install dependencies
npm install
```

## Step 2: Configure Environment

```bash
# Create .env file
cp .env.example .env

# Edit .env with your MongoDB connection string
nano .env
```

### Get MongoDB URI

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Create a free account
3. Create a new cluster
4. Click "Connect"
5. Choose "Drivers"
6. Copy the connection string
7. Replace `<username>` and `<password>` with your database user credentials

Example `.env`:
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb+srv://user:password@cluster0.mongodb.net/expense-tracker?retryWrites=true&w=majority
API_VERSION=v1
LOG_LEVEL=debug
HOST=localhost
```

## Step 3: Start Development Server

```bash
npm run dev
```

You should see:
```
╔════════════════════════════════════════════════════╗
║   Expense Tracker Backend Server Started           ║
╠════════════════════════════════════════════════════╣
║   Environment: DEVELOPMENT                         ║
║   Host:        localhost:5000                      ║
║   API Base:    http://localhost:5000/api/v1        ║
╚════════════════════════════════════════════════════╝
```

## Step 4: Test the API

### Health Check
```bash
curl http://localhost:5000/api/v1/health
```

### Create a User
```bash
curl -X POST http://localhost:5000/api/v1/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "monthlyBudget": 5000
  }'
```

Save the returned `_id` for next step.

### Create an Expense
Replace `USER_ID` with the user ID from previous step:

```bash
curl -X POST http://localhost:5000/api/v1/expenses \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "USER_ID",
    "title": "Lunch",
    "amount": 15.50,
    "category": "Food",
    "date": "2024-01-15T12:00:00Z"
  }'
```

### Get Expense Summary
Replace `USER_ID`:

```bash
curl http://localhost:5000/api/v1/users/USER_ID/expenses/summary
```

Expected response:
```json
{
  "success": true,
  "message": "Expense summary retrieved successfully",
  "data": {
    "totalExpenses": 15.50,
    "remainingBudget": 4984.50,
    "expenseCount": 1,
    "monthlyBudget": 5000,
    "expensesByCategory": {
      "Food": 15.50
    }
  },
  "statusCode": 200
}
```

## Step 5: Explore More Endpoints

All endpoints available:

### Users
- `POST /users` - Create user
- `GET /users` - Get all users (paginated)
- `GET /users/:id` - Get user by ID
- `PUT /users/:id` - Update user
- `DELETE /users/:id` - Delete user

### Expenses
- `POST /expenses` - Create expense
- `GET /expenses/:id` - Get expense
- `PUT /expenses/:id` - Update expense
- `DELETE /expenses/:id` - Delete expense
- `GET /users/:userId/expenses` - Get user expenses (with filtering)
- `GET /users/:userId/expenses/summary` - Get monthly summary

For detailed examples, see [API_EXAMPLES.md](./API_EXAMPLES.md)

## Build for Production

```bash
# Type check
npm run type-check

# Build
npm run build

# Start production server
npm start
```

## Available Scripts

```bash
npm run dev           # Start development server with hot reload
npm run build        # Build TypeScript to JavaScript
npm start            # Start production server
npm run lint         # Run ESLint
npm run format       # Format code with Prettier
npm run type-check   # Run TypeScript type checking
```

## Useful Tools

### Using Postman
1. Import base URL: `http://localhost:5000/api/v1`
2. Create requests for each endpoint
3. Use [API_EXAMPLES.md](./API_EXAMPLES.md) for sample payloads

### Using cURL
All examples use cURL - perfect for quick testing

### Using Insomnia
Free alternative to Postman with similar functionality

## Project Structure

```
src/
├── config/          # Configuration files
├── controllers/     # Request handlers
├── middleware/      # Express middleware
├── models/          # Mongoose schemas
├── routes/          # API routes
├── services/        # Business logic
├── types/           # TypeScript types
├── utils/           # Utility functions
└── index.ts         # Server entry point
```

## Common Issues

### MongoDB Connection Error
```
Error: MONGODB_URI is not defined
```
**Solution**: Check `.env` file has `MONGODB_URI` set correctly

### Port Already in Use
```
Error: listen EADDRINUSE: address already in use :::5000
```
**Solution**: Change `PORT` in `.env` or kill process using port 5000

### Email Already Exists
```
Error: Email already in use
```
**Solution**: Use a different email address for new users

### Invalid User ID
```
Error: Invalid ID format
```
**Solution**: Make sure user ID is a valid MongoDB ObjectId

## Next Steps

1. Read [README.md](./README.md) for full documentation
2. Check [API_EXAMPLES.md](./API_EXAMPLES.md) for more examples
3. Review [DEPLOYMENT.md](./DEPLOYMENT.md) for production deployment
4. See [GIT_WORKFLOW.md](./GIT_WORKFLOW.md) for commit practices

## Getting Help

### Debug Mode
```bash
# Set log level to debug
LOG_LEVEL=debug npm run dev
```

### Check Logs
All requests are logged with response times:
```
GET /api/v1/users 200 5 ms - 245
POST /api/v1/expenses 201 12 ms - 456
```

### MongoDB Atlas
- Monitor queries in MongoDB Atlas dashboard
- Check connection string if database issues
- Verify IP whitelist allows your connection

### Code Quality
```bash
# Type checking
npm run type-check

# Linting
npm run lint

# Format code
npm run format
```

## Features Implemented

✅ User management with validation
✅ Expense tracking by category
✅ Monthly budget tracking
✅ Remaining budget calculation
✅ Expense filtering and pagination
✅ Category-based analysis
✅ Date range filtering
✅ Comprehensive error handling
✅ Request validation with Joi
✅ Security middleware (Helmet, CORS)
✅ TypeScript for type safety
✅ Clean architecture
✅ Mongoose hooks for consistency
✅ Request logging
✅ Response time tracking

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| NODE_ENV | development | Environment (development/production) |
| PORT | 5000 | Server port |
| HOST | localhost | Server host |
| MONGODB_URI | - | MongoDB connection string |
| API_VERSION | v1 | API version |
| LOG_LEVEL | info | Logging level |

## Testing Checklist

- [ ] Health check endpoint works
- [ ] Create user successfully
- [ ] Duplicate email validation works
- [ ] Create expense for user
- [ ] Invalid user ID returns error
- [ ] Get user expenses
- [ ] Filter expenses by category
- [ ] Get monthly summary
- [ ] Update expense
- [ ] Delete expense
- [ ] Pagination works
- [ ] Date validation works

## Performance Tips

1. **Use pagination** for large datasets
2. **Filter by date** to reduce query results
3. **Category filtering** for grouped analysis
4. **Indexes already configured** for optimal queries

## Security Notes

- Emails are unique and case-insensitive
- Amounts validated to be positive
- Future dates rejected for expenses
- User existence verified before expense creation
- All inputs validated before processing
- CORS configured for security
- Helmet headers for additional protection

## Ready to Deploy?

See [DEPLOYMENT.md](./DEPLOYMENT.md) for production deployment options including Vercel, Heroku, AWS, and more.

---

**Having issues?** Check [README.md](./README.md) for complete documentation or review error messages carefully - they're designed to be helpful!
