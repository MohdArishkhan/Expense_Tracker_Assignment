import mongoose, { Schema, Document, Model } from 'mongoose';
import { IExpense } from '../types';
import User from './User';

export interface IExpenseDocument extends IExpense, Document {}

const EXPENSE_CATEGORIES = [
  'Food',
  'Travel',
  'Shopping',
  'Entertainment',
  'Utilities',
  'Healthcare',
  'Education',
  'Other',
];

const expenseSchema = new Schema<IExpenseDocument>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User ID is required'],
      validate: {
        isAsync: true,
        validator: async (value: string) => {
          const user = await User.findById(value);
          return !!user;
        },
        message: 'User does not exist',
      },
    },
    title: {
      type: String,
      required: [true, 'Expense title/description is required'],
      trim: true,
      minlength: [2, 'Title must be at least 2 characters long'],
      maxlength: [200, 'Title cannot exceed 200 characters'],
    },
    amount: {
      type: Number,
      required: [true, 'Amount is required'],
      min: [0.01, 'Amount must be greater than 0'],
      validate: {
        validator: function (value: number) {
          return value > 0;
        },
        message: 'Amount must be a positive number',
      },
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: {
        values: EXPENSE_CATEGORIES,
        message: `Category must be one of: ${EXPENSE_CATEGORIES.join(', ')}`,
      },
    },
    date: {
      type: Date,
      required: [true, 'Date is required'],
      validate: {
        validator: function (value: Date) {
          return value <= new Date();
        },
        message: 'Expense date cannot be in the future',
      },
    },
  },
  {
    timestamps: true,
    collection: 'expenses',
  }
);

// Middleware: Validate user exists before saving
expenseSchema.pre('save', async function (next) {
  if (this.isModified('userId')) {
    const user = await User.findById(this.userId);
    if (!user) {
      const error = new Error('User not found');
      (error as any).statusCode = 404;
      return next(error);
    }
  }
  next();
});

// Middleware: Populate user data when retrieving expenses
expenseSchema.pre(/^find/, function (next) {
  this.populate('userId', 'name email monthlyBudget');
  next();
});

// Indexes for better query performance
expenseSchema.index({ userId: 1, date: -1 });
expenseSchema.index({ userId: 1, category: 1 });
expenseSchema.index({ createdAt: -1 });

// Instance methods
expenseSchema.methods.toJSON = function () {
  const expense = this.toObject();
  delete expense.__v;
  return expense;
};

const Expense: Model<IExpenseDocument> = mongoose.model<IExpenseDocument>(
  'Expense',
  expenseSchema
);

export default Expense;
