import mongoose, { Schema, Document, Model } from 'mongoose';
import { IUser } from '../types';

export interface IUserDocument extends IUser, Document {}

const userSchema = new Schema<IUserDocument>(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      minlength: [2, 'Name must be at least 2 characters long'],
      maxlength: [100, 'Name cannot exceed 100 characters'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [
        /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
        'Please provide a valid email address',
      ],
    },
    monthlyBudget: {
      type: Number,
      required: [true, 'Monthly budget is required'],
      min: [0.01, 'Monthly budget must be greater than 0'],
      validate: {
        validator: function (value: number) {
          return value > 0;
        },
        message: 'Monthly budget must be a positive number',
      },
    },
  },
  {
    timestamps: true,
    collection: 'users',
  }
);

// Middleware: Ensure email uniqueness with proper error handling
userSchema.pre('save', async function (next) {
  if (!this.isModified('email')) {
    return next();
  }

  try {
    const existingUser = await mongoose.model<IUserDocument>(
      'User'
    ).findOne({
      email: this.email,
      _id: { $ne: this._id },
    });

    if (existingUser) {
      const error = new Error('Email already in use');
      (error as any).statusCode = 400;
      return next(error);
    }

    next();
  } catch (error) {
    next(error as Error);
  }
});

// Middleware: Index for email uniqueness
userSchema.index({ email: 1 }, { unique: true, sparse: true });

// Instance methods
userSchema.methods.toJSON = function () {
  const user = this.toObject();
  delete user.__v;
  return user;
};

const User: Model<IUserDocument> = mongoose.model<IUserDocument>(
  'User',
  userSchema
);

export default User;
