import express, { Express, Router } from 'express';
import { connectDatabase, disconnectDatabase } from './config/database';
import { config } from './config/env';
import { securityMiddleware } from './middleware/security';
import { requestLogger, responseTimeMiddleware } from './middleware/logger';
import { errorHandler } from './middleware/errorHandler';
import { createRoutes } from './routes';
import { userExpenseRoutes } from './routes/userExpenseRoutes';
import { UserController } from './controllers/userController';

const app: Express = express();

// ========== INITIALIZATION ==========

/**
 * Start the Express server and connect to MongoDB
 */
const startServer = async (): Promise<void> => {
  try {
    // Connect to MongoDB
    await connectDatabase();

    // ========== MIDDLEWARE SETUP ==========

    // Parse JSON and URL-encoded request bodies
    app.use(express.json({ limit: '10mb' }));
    app.use(express.urlencoded({ extended: true, limit: '10mb' }));

    // Request logging and response time tracking
    app.use(requestLogger);
    app.use(responseTimeMiddleware);

    // Security middleware
    app.use(...securityMiddleware);

    // ========== ROUTES SETUP ==========

    const apiRouter = Router();

    // Health check
    apiRouter.get('/health', (req, res) => {
      res.status(200).json({
        success: true,
        message: 'Server is healthy',
        timestamp: new Date().toISOString(),
        environment: config.nodeEnv,
      });
    });

    // User routes with nested expense routes
    apiRouter.use('/users', UserController.getUser, (req, res, next) => {
      // This ensures that /users/:id routes work, then apply nested routes
      next();
    });

    // Register all routes
    createRoutes(apiRouter);

    // Mount expense routes under users
    apiRouter.use('/users/:userId/expenses', userExpenseRoutes);

    // Mount API router
    app.use(`/api/${config.apiVersion}`, apiRouter);

    // ========== ERROR HANDLING ==========

    // Global error handler (must be last)
    app.use(errorHandler);

    // ========== START SERVER ==========

    const server = app.listen(config.port, config.host, () => {
      console.log(`
╔════════════════════════════════════════════════════╗
║   Expense Tracker Backend Server Started           ║
╠════════════════════════════════════════════════════╣
║   Environment: ${config.nodeEnv.toUpperCase().padEnd(32)}║
║   Host:        ${config.host}:${config.port.toString().padEnd(30)}║
║   API Base:    http://${config.host}:${config.port}/api/${config.apiVersion}${' '.repeat(20)}║
╚════════════════════════════════════════════════════╝
      `);
    });

    // ========== GRACEFUL SHUTDOWN ==========

    const gracefulShutdown = async (signal: string): Promise<void> => {
      console.log(`\n[${signal}] Shutting down gracefully...`);
      server.close(async () => {
        await disconnectDatabase();
        console.log('Server closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    process.on('uncaughtException', (error) => {
      console.error('[UNCAUGHT EXCEPTION]', error);
      process.exit(1);
    });

    process.on('unhandledRejection', (reason, promise) => {
      console.error('[UNHANDLED REJECTION]', { reason, promise });
      process.exit(1);
    });
  } catch (error) {
    console.error('[STARTUP ERROR]', error);
    process.exit(1);
  }
};

// Start the server
startServer();
