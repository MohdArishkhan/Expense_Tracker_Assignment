import { Router, Request, Response } from 'express';
import { userRoutes } from './userRoutes';
import { expenseRoutes } from './expenseRoutes';

export const createRoutes = (app: Router): void => {
  // Health check endpoint
  app.get('/health', (req: Request, res: Response) => {
    res.status(200).json({
      success: true,
      message: 'Server is running',
      timestamp: new Date().toISOString(),
    });
  });

  // API routes
  const apiRouter = Router();
  apiRouter.use('/users', userRoutes);
  apiRouter.use('/expenses', expenseRoutes);

  // Mount API routes with version prefix
  app.use('/api/v1', apiRouter);

  // 404 handler
  app.use((req: Request, res: Response) => {
    res.status(404).json({
      success: false,
      message: `Route not found: ${req.path}`,
      statusCode: 404,
    });
  });
};
