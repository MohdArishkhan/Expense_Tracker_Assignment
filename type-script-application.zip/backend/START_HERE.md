# 🚀 START HERE

Welcome to your **Personal Expense Tracker Backend** application!

This is a complete, production-ready backend service built with **TypeScript, Node.js, Express, and MongoDB**.

## ⚡ Quick Start (5 Minutes)

### 1. Install Dependencies
```bash
npm install
```

### 2. Setup Environment
```bash
cp .env.example .env
```

Edit `.env` and add your MongoDB connection string from [MongoDB Atlas](https://www.mongodb.com/cloud/atlas):

```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/expense-tracker
```

### 3. Start Development Server
```bash
npm run dev
```

You should see:
```
╔════════════════════════════════════════════════════╗
║   Expense Tracker Backend Server Started           ║
╠════════════════════════════════════════════════════╣
║   Environment: DEVELOPMENT                         ║
║   Host:        localhost:5000                      ║
║   API Base:    http://localhost:5000/api/v1        ║
╚════════════════════════════════════════════════════╝
```

### 4. Test It Works
```bash
curl http://localhost:5000/api/v1/health
```

Expected response:
```json
{
  "success": true,
  "message": "Server is healthy",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "environment": "development"
}
```

✅ **You're running!**

---

## 📚 Documentation Guide

### I want to...

**Get started quickly**
→ You're reading it! Next, see [QUICK_START.md](./QUICK_START.md)

**Understand the API**
→ Read [API_EXAMPLES.md](./API_EXAMPLES.md) for examples

**Learn the architecture**
→ Read [ARCHITECTURE.md](./ARCHITECTURE.md)

**Deploy to production**
→ Follow [DEPLOYMENT.md](./DEPLOYMENT.md)

**Understand Git workflow**
→ Check [GIT_WORKFLOW.md](./GIT_WORKFLOW.md)

**Find files/functions**
→ See [PROJECT_TREE.md](./PROJECT_TREE.md)

**See all documentation**
→ Visit [DOCUMENTATION_INDEX.md](./DOCUMENTATION_INDEX.md)

---

## 🎯 What You Can Do

### Create a User
```bash
curl -X POST http://localhost:5000/api/v1/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "monthlyBudget": 5000
  }'
```

Save the `_id` from response.

### Create an Expense
Replace `USER_ID` with the ID from above:

```bash
curl -X POST http://localhost:5000/api/v1/expenses \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "USER_ID",
    "title": "Lunch",
    "amount": 15.50,
    "category": "Food",
    "date": "2024-01-15T12:00:00Z"
  }'
```

### Get Monthly Summary
Replace `USER_ID`:

```bash
curl http://localhost:5000/api/v1/users/USER_ID/expenses/summary
```

Expected response:
```json
{
  "success": true,
  "data": {
    "totalExpenses": 15.50,
    "remainingBudget": 4984.50,
    "expenseCount": 1,
    "monthlyBudget": 5000,
    "expensesByCategory": {
      "Food": 15.50
    }
  }
}
```

---

## 📋 Available Scripts

```bash
npm run dev           # Development server (with hot reload)
npm run build        # Build TypeScript to JavaScript
npm start            # Production server
npm run type-check   # Type checking
npm run lint         # Linting
npm run format       # Code formatting
```

---

## 🗂️ Project Structure

```
backend/
├── src/              # Source code
│   ├── config/       # Configuration
│   ├── controllers/  # API handlers
│   ├── middleware/   # Express middleware
│   ├── models/       # Database schemas
│   ├── routes/       # API routes
│   ├── services/     # Business logic
│   ├── types/        # TypeScript types
│   ├── utils/        # Helper functions
│   └── index.ts      # Server entry point
│
├── docs/             # Documentation files
│
└── package.json      # Dependencies
```

---

## 🔗 All API Endpoints

### Users
- `POST /users` - Create user
- `GET /users` - List users
- `GET /users/:id` - Get user
- `PUT /users/:id` - Update user
- `DELETE /users/:id` - Delete user

### Expenses
- `POST /expenses` - Create expense
- `GET /expenses/:id` - Get expense
- `GET /users/:userId/expenses` - List user expenses
- `GET /users/:userId/expenses/summary` - Get summary
- `PUT /expenses/:id` - Update expense
- `DELETE /expenses/:id` - Delete expense

Full details: [API_EXAMPLES.md](./API_EXAMPLES.md)

---

## 💡 Features

✅ User management with email uniqueness
✅ Expense tracking by category
✅ Monthly budget tracking
✅ Remaining budget calculation
✅ Pagination and filtering
✅ TypeScript strict mode
✅ Comprehensive error handling
✅ Security middleware
✅ Request logging
✅ Production-ready

---

## 🔧 Troubleshooting

### MongoDB Connection Error
```
Error: MONGODB_URI is not defined
```
**Solution**: Check `.env` file has `MONGODB_URI` set

### Port Already in Use
```
Error: listen EADDRINUSE: address already in use :::5000
```
**Solution**: Change `PORT` in `.env` or kill process

### Email Already Exists
```
Error: Email already in use
```
**Solution**: Use a different email for new user

### Need Help?
Check the relevant documentation file:
- Setup issues → [QUICK_START.md](./QUICK_START.md)
- API issues → [API_EXAMPLES.md](./API_EXAMPLES.md)
- Architecture → [ARCHITECTURE.md](./ARCHITECTURE.md)
- Deployment → [DEPLOYMENT.md](./DEPLOYMENT.md)

---

## 📖 Learning Path

### Beginner (15 minutes)
1. ✅ Get server running (done!)
2. Test endpoints using [API_EXAMPLES.md](./API_EXAMPLES.md)
3. Read [README.md](./README.md) - Features section

### Intermediate (45 minutes)
1. Complete Beginner
2. Read [ARCHITECTURE.md](./ARCHITECTURE.md)
3. Explore source code
4. Try modifying endpoints

### Advanced (90 minutes)
1. Complete Intermediate
2. Read [DEPLOYMENT.md](./DEPLOYMENT.md)
3. Study [GIT_WORKFLOW.md](./GIT_WORKFLOW.md)
4. Deploy to production

---

## 🚀 Ready to Deploy?

When you want to go to production:

1. Read [DEPLOYMENT.md](./DEPLOYMENT.md)
2. Choose deployment platform (Vercel, Heroku, AWS, etc.)
3. Follow platform-specific instructions
4. Build & deploy

```bash
npm run build  # Build for production
npm start      # Run production server
```

---

## 📞 Useful Commands

### Development
```bash
npm run dev              # Start with hot reload
npm run type-check      # Check types
npm run lint            # Check code quality
```

### Production
```bash
npm run build           # Compile TypeScript
npm start               # Start server
```

### Git
```bash
git add .
git commit -m "feat(scope): description"
git push origin branch-name
```

---

## 🎓 Complete Documentation

| Document | Purpose | Read Time |
|----------|---------|-----------|
| [QUICK_START.md](./QUICK_START.md) | Quick setup | 5 min |
| [README.md](./README.md) | Full reference | 15 min |
| [API_EXAMPLES.md](./API_EXAMPLES.md) | Endpoint examples | 10 min |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | System design | 20 min |
| [DEPLOYMENT.md](./DEPLOYMENT.md) | Production setup | 15 min |
| [GIT_WORKFLOW.md](./GIT_WORKFLOW.md) | Git practices | 10 min |
| [PROJECT_TREE.md](./PROJECT_TREE.md) | File structure | 10 min |
| [PROJECT_SUMMARY.md](./PROJECT_SUMMARY.md) | Overview | 5 min |
| [DOCUMENTATION_INDEX.md](./DOCUMENTATION_INDEX.md) | Doc guide | 5 min |

---

## ✨ What's Included

✅ **Complete Backend**
- 13 source code files
- Production-ready
- Type-safe TypeScript

✅ **Comprehensive Documentation**
- 10 documentation files
- ~3,500 lines of docs
- Examples for everything

✅ **Ready to Deploy**
- Environment configuration
- Multiple deployment options
- Production checklist

✅ **Developer Friendly**
- Clean code
- Easy to extend
- Well-organized

---

## 🎯 Next Steps

### Right Now
1. ✅ You've got it running
2. Try endpoints from [API_EXAMPLES.md](./API_EXAMPLES.md)
3. Create a user and expense

### Today
1. Read [README.md](./README.md)
2. Explore [API_EXAMPLES.md](./API_EXAMPLES.md)
3. Review [ARCHITECTURE.md](./ARCHITECTURE.md)

### This Week
1. Understand [PROJECT_TREE.md](./PROJECT_TREE.md)
2. Try [DEPLOYMENT.md](./DEPLOYMENT.md)
3. Review [GIT_WORKFLOW.md](./GIT_WORKFLOW.md)

---

## 💬 Questions?

**How do I...?**
- Use the API → [API_EXAMPLES.md](./API_EXAMPLES.md)
- Deploy it → [DEPLOYMENT.md](./DEPLOYMENT.md)
- Understand it → [ARCHITECTURE.md](./ARCHITECTURE.md)
- Set it up → [QUICK_START.md](./QUICK_START.md)
- Contribute → [GIT_WORKFLOW.md](./GIT_WORKFLOW.md)

**Everything else?**
→ [DOCUMENTATION_INDEX.md](./DOCUMENTATION_INDEX.md)

---

## 🎉 You're All Set!

Your Personal Expense Tracker Backend is ready to use. It's:
- ✅ Running locally
- ✅ Well-documented
- ✅ Production-ready
- ✅ Easy to extend
- ✅ Type-safe
- ✅ Secure

**Happy coding!** 🚀

---

**Need quick reference?** Create a bookmark to:
- [README.md](./README.md) - Complete reference
- [API_EXAMPLES.md](./API_EXAMPLES.md) - API endpoints
- [DOCUMENTATION_INDEX.md](./DOCUMENTATION_INDEX.md) - Find anything

**Current Status**: ✅ Running at `http://localhost:5000/api/v1`
