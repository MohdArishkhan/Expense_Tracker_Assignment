# API Examples & Testing Guide

This document provides practical examples for testing all API endpoints.

## Base URL
```
http://localhost:5000/api/v1
```

## Health Check

```bash
curl -X GET http://localhost:5000/api/v1/health
```

**Response:**
```json
{
  "success": true,
  "message": "Server is healthy",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "environment": "development"
}
```

## User Endpoints

### 1. Create User

```bash
curl -X POST http://localhost:5000/api/v1/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "monthlyBudget": 5000
  }'
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "monthlyBudget": 5000,
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  },
  "statusCode": 201
}
```

### 2. Get User by ID

```bash
curl -X GET http://localhost:5000/api/v1/users/507f1f77bcf86cd799439011
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "User retrieved successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "monthlyBudget": 5000,
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  },
  "statusCode": 200
}
```

### 3. Get All Users (with Pagination)

```bash
# Get first page with 10 items
curl -X GET "http://localhost:5000/api/v1/users?page=1&limit=10"

# Get specific page
curl -X GET "http://localhost:5000/api/v1/users?page=2&limit=5"
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Users retrieved successfully",
  "data": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "john@example.com",
      "monthlyBudget": 5000,
      "createdAt": "2024-01-15T10:30:00.000Z",
      "updatedAt": "2024-01-15T10:30:00.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "statusCode": 200
}
```

### 4. Update User

```bash
curl -X PUT http://localhost:5000/api/v1/users/507f1f77bcf86cd799439011 \
  -H "Content-Type: application/json" \
  -d '{
    "monthlyBudget": 6000
  }'
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "User updated successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "monthlyBudget": 6000,
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:35:00.000Z"
  },
  "statusCode": 200
}
```

### 5. Delete User

```bash
curl -X DELETE http://localhost:5000/api/v1/users/507f1f77bcf86cd799439011
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "User deleted successfully",
  "statusCode": 200
}
```

## Expense Endpoints

### 1. Create Expense

```bash
curl -X POST http://localhost:5000/api/v1/expenses \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "507f1f77bcf86cd799439011",
    "title": "Lunch at restaurant",
    "amount": 25.50,
    "category": "Food",
    "date": "2024-01-15T12:00:00Z"
  }'
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Expense created successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439012",
    "userId": {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "john@example.com",
      "monthlyBudget": 6000
    },
    "title": "Lunch at restaurant",
    "amount": 25.50,
    "category": "Food",
    "date": "2024-01-15T12:00:00.000Z",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  },
  "statusCode": 201
}
```

### 2. Get Expense by ID

```bash
curl -X GET http://localhost:5000/api/v1/expenses/507f1f77bcf86cd799439012
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Expense retrieved successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439012",
    "userId": {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "john@example.com",
      "monthlyBudget": 6000
    },
    "title": "Lunch at restaurant",
    "amount": 25.50,
    "category": "Food",
    "date": "2024-01-15T12:00:00.000Z",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  },
  "statusCode": 200
}
```

### 3. Get User Expenses (with Pagination & Filtering)

```bash
# Get all expenses for user
curl -X GET "http://localhost:5000/api/v1/users/507f1f77bcf86cd799439011/expenses?page=1&limit=10"

# Filter by category
curl -X GET "http://localhost:5000/api/v1/users/507f1f77bcf86cd799439011/expenses?category=Food"

# Filter by date range
curl -X GET "http://localhost:5000/api/v1/users/507f1f77bcf86cd799439011/expenses?startDate=2024-01-01&endDate=2024-01-31"

# Combine filters
curl -X GET "http://localhost:5000/api/v1/users/507f1f77bcf86cd799439011/expenses?category=Food&page=1&limit=5&startDate=2024-01-01&endDate=2024-01-31"
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "User expenses retrieved successfully",
  "data": [
    {
      "_id": "507f1f77bcf86cd799439012",
      "userId": {
        "_id": "507f1f77bcf86cd799439011",
        "name": "John Doe",
        "email": "john@example.com",
        "monthlyBudget": 6000
      },
      "title": "Lunch at restaurant",
      "amount": 25.50,
      "category": "Food",
      "date": "2024-01-15T12:00:00.000Z",
      "createdAt": "2024-01-15T10:30:00.000Z",
      "updatedAt": "2024-01-15T10:30:00.000Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 1,
    "pages": 1
  },
  "statusCode": 200
}
```

### 4. Get Monthly Expense Summary

```bash
curl -X GET http://localhost:5000/api/v1/users/507f1f77bcf86cd799439011/expenses/summary
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Expense summary retrieved successfully",
  "data": {
    "totalExpenses": 25.50,
    "remainingBudget": 5974.50,
    "expenseCount": 1,
    "monthlyBudget": 6000,
    "expensesByCategory": {
      "Food": 25.50
    }
  },
  "statusCode": 200
}
```

### 5. Update Expense

```bash
curl -X PUT http://localhost:5000/api/v1/expenses/507f1f77bcf86cd799439012 \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 30.00,
    "title": "Updated lunch at restaurant"
  }'
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Expense updated successfully",
  "data": {
    "_id": "507f1f77bcf86cd799439012",
    "userId": {
      "_id": "507f1f77bcf86cd799439011",
      "name": "John Doe",
      "email": "john@example.com",
      "monthlyBudget": 6000
    },
    "title": "Updated lunch at restaurant",
    "amount": 30.00,
    "category": "Food",
    "date": "2024-01-15T12:00:00.000Z",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:35:00.000Z"
  },
  "statusCode": 200
}
```

### 6. Delete Expense

```bash
curl -X DELETE http://localhost:5000/api/v1/expenses/507f1f77bcf86cd799439012
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Expense deleted successfully",
  "statusCode": 200
}
```

## Error Examples

### Validation Error

```bash
curl -X POST http://localhost:5000/api/v1/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "J",
    "email": "invalid-email",
    "monthlyBudget": -100
  }'
```

**Response (400 Bad Request):**
```json
{
  "success": false,
  "message": "Name must be at least 2 characters long, Invalid email format, Monthly budget must be greater than 0",
  "error": "Validation failed",
  "statusCode": 400
}
```

### Not Found Error

```bash
curl -X GET http://localhost:5000/api/v1/users/507f1f77bcf86cd799999999
```

**Response (404 Not Found):**
```json
{
  "success": false,
  "message": "User not found",
  "error": "User not found",
  "statusCode": 404
}
```

### Duplicate Email Error

```bash
curl -X POST http://localhost:5000/api/v1/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "monthlyBudget": 5000
  }'
```

After creating first user with same email:

**Response (409 Conflict):**
```json
{
  "success": false,
  "message": "email already exists",
  "error": "email already exists",
  "statusCode": 409
}
```

## Testing with Postman

1. Import the base URL: `http://localhost:5000/api/v1`
2. Create requests for each endpoint
3. Set appropriate headers: `Content-Type: application/json`
4. Use the examples above for request bodies
5. Test error cases by providing invalid data

## Testing with Thunder Client (VS Code)

1. Install Thunder Client extension
2. Create collection for "Expense Tracker"
3. Add requests using the examples above
4. Test endpoints with different parameters

## Important Notes

- Replace user IDs and expense IDs with actual values from your database
- Dates should be in ISO 8601 format
- Monthly budget must be positive
- Expense dates cannot be in the future
- Category must be one of: Food, Travel, Shopping, Entertainment, Utilities, Healthcare, Education, Other
- Email must be unique across all users
- Pagination defaults to page 1, limit 10
