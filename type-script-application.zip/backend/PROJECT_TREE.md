# Project Tree Reference

Complete directory structure of the Personal Expense Tracker Backend.

## Full Project Structure

```
backend/
├── src/                                    # Source code directory
│   ├── config/
│   │   ├── database.ts                    # MongoDB connection & management
│   │   └── env.ts                         # Environment configuration & validation
│   │
│   ├── controllers/
│   │   ├── userController.ts              # User endpoints (CRUD, list)
│   │   │                                  # - POST /users (create)
│   │   │                                  # - GET /users (list with pagination)
│   │   │                                  # - GET /users/:id (get)
│   │   │                                  # - PUT /users/:id (update)
│   │   │                                  # - DELETE /users/:id (delete)
│   │   │
│   │   └── expenseController.ts           # Expense endpoints (CRUD + summary)
│   │                                      # - POST /expenses (create)
│   │                                      # - GET /expenses/:id (get)
│   │                                      # - GET /users/:userId/expenses (list)
│   │                                      # - GET /users/:userId/summary (summary)
│   │                                      # - PUT /expenses/:id (update)
│   │                                      # - DELETE /expenses/:id (delete)
│   │
│   ├── middleware/
│   │   ├── errorHandler.ts                # Global error handling
│   │   │                                  # - Error class hierarchy
│   │   │                                  # - MongoDB error mapping
│   │   │                                  # - asyncHandler wrapper
│   │   │
│   │   ├── logger.ts                      # Request logging & response time
│   │   │                                  # - Morgan integration
│   │   │                                  # - Response time tracking
│   │   │
│   │   └── security.ts                    # Security middleware
│   │                                      # - Helmet (security headers)
│   │                                      # - CORS configuration
│   │                                      # - Request size limiting
│   │                                      # - Custom security headers
│   │
│   ├── models/
│   │   ├── User.ts                        # User schema with hooks
│   │   │                                  # Fields: name, email, monthlyBudget
│   │   │                                  # Hooks: pre-save email validation
│   │   │                                  # Indexes: unique email
│   │   │
│   │   └── Expense.ts                     # Expense schema with relationships
│   │                                      # Fields: userId, title, amount, category, date
│   │                                      # Hooks: pre-save validation, pre-find population
│   │                                      # Indexes: userId, category, createdAt
│   │
│   ├── routes/
│   │   ├── index.ts                       # Route mounting & configuration
│   │   │                                  # - API versioning
│   │   │                                  # - Health check endpoint
│   │   │                                  # - 404 handler
│   │   │
│   │   ├── userRoutes.ts                  # User CRUD routes
│   │   │                                  # - POST, GET, PUT, DELETE /users
│   │   │                                  # - GET /users/:id
│   │   │
│   │   ├── expenseRoutes.ts               # Expense CRUD routes
│   │   │                                  # - POST, GET, PUT, DELETE /expenses
│   │   │                                  # - GET /expenses/:id
│   │   │
│   │   └── userExpenseRoutes.ts           # Nested user expense routes
│   │                                      # - GET /users/:userId/expenses
│   │                                      # - GET /users/:userId/expenses/summary
│   │
│   ├── services/
│   │   ├── userService.ts                 # User business logic
│   │   │                                  # - createUser()
│   │   │                                  # - getUserById()
│   │   │                                  # - getUserByEmail()
│   │   │                                  # - updateUser()
│   │   │                                  # - deleteUser()
│   │   │                                  # - getAllUsers()
│   │   │
│   │   └── expenseService.ts              # Expense business logic
│   │                                      # - createExpense()
│   │                                      # - getExpenseById()
│   │                                      # - getUserExpenses() [with filtering]
│   │                                      # - getMonthlyExpenseSummary()
│   │                                      # - updateExpense()
│   │                                      # - deleteExpense()
│   │                                      # - deleteUserExpenses()
│   │
│   ├── types/
│   │   └── index.ts                       # TypeScript interfaces
│   │                                      # - IUser, IExpense, IExpenseSummary
│   │                                      # - ApiResponse, PaginatedResponse
│   │                                      # - IUserDocument, IExpenseDocument
│   │                                      # - PaginationOptions
│   │
│   ├── utils/
│   │   ├── errors.ts                      # Custom error classes
│   │   │                                  # - AppError (base)
│   │   │                                  # - ValidationError (400)
│   │   │                                  # - NotFoundError (404)
│   │   │                                  # - ConflictError (409)
│   │   │                                  # - UnauthorizedError (401)
│   │   │                                  # - ForbiddenError (403)
│   │   │
│   │   ├── response.ts                    # API response helpers
│   │   │                                  # - sendSuccess()
│   │   │                                  # - sendPaginatedSuccess()
│   │   │                                  # - sendError()
│   │   │                                  # - sendCreated()
│   │   │
│   │   ├── validators.ts                  # Joi validation schemas
│   │   │                                  # - userCreateSchema
│   │   │                                  # - expenseCreateSchema
│   │   │                                  # - paginationSchema
│   │   │                                  # - validateData()
│   │   │
│   │   └── pagination.ts                  # Pagination utilities
│   │                                      # - getPaginationOptions()
│   │                                      # - calculatePaginationMetadata()
│   │
│   └── index.ts                           # Server entry point
│                                          # - Express app initialization
│                                          # - Middleware setup
│                                          # - Route registration
│                                          # - Database connection
│                                          # - Graceful shutdown
│
├── .env.example                           # Environment variables template
│                                          # - NODE_ENV, PORT, HOST
│                                          # - MONGODB_URI
│                                          # - API_VERSION, LOG_LEVEL
│
├── .gitignore                             # Git ignore configuration
│                                          # - node_modules/
│                                          # - dist/, build/
│                                          # - .env files
│                                          # - IDE files
│                                          # - OS files
│                                          # - Logs
│
├── tsconfig.json                          # TypeScript configuration
│                                          # - Strict mode enabled
│                                          # - Target: ES2020
│                                          # - Module: commonjs
│                                          # - Declaration maps enabled
│
├── package.json                           # Dependencies & scripts
│                                          # - express, mongoose, typescript
│                                          # - dev, build, start scripts
│                                          # - lint, format, type-check scripts
│
├── README.md                              # Comprehensive documentation
│                                          # - Features, tech stack
│                                          # - Setup & installation
│                                          # - API documentation
│                                          # - Error handling
│                                          # - Database setup
│                                          # - Middleware architecture
│
├── QUICK_START.md                         # 5-minute quick start
│                                          # - Prerequisites
│                                          # - Installation steps
│                                          # - Testing checklist
│                                          # - Common issues
│
├── API_EXAMPLES.md                        # Endpoint examples
│                                          # - cURL examples for all endpoints
│                                          # - Request/response samples
│                                          # - Error examples
│                                          # - Testing tools
│
├── ARCHITECTURE.md                        # System architecture
│                                          # - Layered architecture diagram
│                                          # - Data flow diagrams
│                                          # - Error handling architecture
│                                          # - Database design
│                                          # - Security architecture
│                                          # - Performance considerations
│
├── DEPLOYMENT.md                          # Production deployment
│                                          # - Deployment options
│                                          # - Environment setup
│                                          # - Docker configuration
│                                          # - Monitoring setup
│                                          # - Backup procedures
│                                          # - CI/CD examples
│
├── GIT_WORKFLOW.md                        # Git practices & workflow
│                                          # - Commit message format
│                                          # - Recommended commit history
│                                          # - Branching strategy
│                                          # - Code review guidelines
│                                          # - Troubleshooting guide
│
├── PROMPTS_USED.md                        # AI assistance documentation
│                                          # - Development tools used
│                                          # - Implementation patterns
│                                          # - Design decisions
│
├── PROJECT_SUMMARY.md                     # Project overview
│                                          # - Features checklist
│                                          # - Project structure
│                                          # - Technology stack
│                                          # - Getting started
│
└── PROJECT_TREE.md                        # This file
                                           # - Complete file structure
                                           # - File descriptions
```

## File Statistics

### Source Code Files: 13
```
config/                2 files  (~100 lines)
controllers/           2 files  (~240 lines)
middleware/            3 files  (~170 lines)
models/                2 files  (~200 lines)
routes/                4 files  (~100 lines)
services/              2 files  (~290 lines)
types/                 1 file   (~50 lines)
utils/                 4 files  (~230 lines)
index.ts               1 file   (~115 lines)
                      ___________________
Total Source:         ~1,495 lines of code
```

### Configuration Files: 4
```
.env.example           ~13 lines
.gitignore             ~46 lines
tsconfig.json          ~31 lines
package.json           ~41 lines
                      ___________________
Total Config:         ~131 lines
```

### Documentation Files: 8
```
README.md              ~488 lines (comprehensive guide)
QUICK_START.md         ~335 lines (quick start)
API_EXAMPLES.md        ~437 lines (examples)
ARCHITECTURE.md        ~566 lines (architecture)
DEPLOYMENT.md          ~316 lines (deployment)
GIT_WORKFLOW.md        ~489 lines (git workflow)
PROMPTS_USED.md        ~153 lines (ai assistance)
PROJECT_SUMMARY.md     ~495 lines (overview)
PROJECT_TREE.md        This file (~300+ lines)
                      ___________________
Total Docs:           ~3,479 lines of documentation
```

## Quick File Reference

### Need to...

**Modify API behavior?**
- Controllers: `src/controllers/*`
- Routes: `src/routes/*`

**Add/change validation rules?**
- Validators: `src/utils/validators.ts`
- Models: `src/models/*` (schema validation)

**Add business logic?**
- Services: `src/services/*`

**Add database operations?**
- Models: `src/models/*`

**Change error handling?**
- Error classes: `src/utils/errors.ts`
- Error handler: `src/middleware/errorHandler.ts`

**Add security features?**
- Security middleware: `src/middleware/security.ts`

**Track requests?**
- Logger: `src/middleware/logger.ts`

**Deploy to production?**
- DEPLOYMENT.md

**Understand architecture?**
- ARCHITECTURE.md

**Get started quickly?**
- QUICK_START.md

**Test endpoints?**
- API_EXAMPLES.md

## Import Structure

```
src/
├── Config → Database & Environment
├── Utils → Errors, Validation, Response, Pagination
├── Middleware → Security, Logger, Error Handler
├── Types → Interfaces
├── Models → Schemas (uses Mongoose)
├── Services → Business Logic (uses Models)
├── Controllers → Request Handlers (uses Services, Validators)
├── Routes → Endpoint Mapping (uses Controllers)
└── index.ts → Application Entry (uses all layers)
```

## Dependency Graph

```
Controllers
  ↓
  ├─ Services (business logic)
  │   ├─ Models (database schemas)
  │   └─ Services (dependencies on each other)
  ├─ Validators (input validation)
  ├─ Response Helpers (formatting)
  └─ Errors (custom error classes)

Routes
  ↓
  └─ Controllers

Middleware
  ├─ Security (Helmet, CORS)
  ├─ Logger (Morgan)
  └─ Error Handler

Database Config
  └─ Models (Mongoose schemas)

Environment Config
  └─ Database, Port, etc.
```

## Version Control

### Git Tracking
- All source files tracked
- .env files ignored (use .env.example)
- dist/ and build/ ignored
- node_modules/ ignored
- IDE files ignored

### Commit Structure
```
chore(init):          Project initialization
feat(config):         Configuration setup
feat(db):             Database schemas
feat(middleware):     Middleware setup
feat(services):       Business logic
feat(controllers):    API endpoints
feat(routes):         Route definitions
feat(app):            Server initialization
docs(*):              Documentation
```

## Environment Variables

Located in: `.env` (create from `.env.example`)

```
NODE_ENV              development/production
PORT                  5000 (default)
HOST                  localhost (default)
MONGODB_URI           MongoDB connection string
API_VERSION           v1 (default)
LOG_LEVEL             debug/info/warn/error
CORS_ORIGIN           Domain for CORS
```

## Running the Application

```bash
# Development (watch mode)
npm run dev

# Production
npm run build
npm start

# Verification
npm run type-check
npm run lint
npm run format
```

## Key Architectural Decisions

### Layered Architecture
- **Routes Layer**: HTTP endpoint definitions
- **Controller Layer**: Request/response handling
- **Service Layer**: Business logic and calculations
- **Model Layer**: Data structure and validation
- **Database Layer**: MongoDB via Mongoose

### Error Handling
- Custom error classes for different scenarios
- Global error handler middleware
- Graceful error responses

### Validation Strategy
- Multi-level validation (controller, model, hooks)
- Joi for input validation
- Mongoose schema validation
- Pre-save hooks for complex validation

### Security
- Helmet for HTTP headers
- CORS for cross-origin requests
- Request size limiting
- Input validation
- Type safety with TypeScript

---

**Status: Complete and production-ready**

For more details, see individual documentation files listed above.
