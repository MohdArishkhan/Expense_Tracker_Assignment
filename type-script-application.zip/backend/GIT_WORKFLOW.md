# Git Workflow & Commit History

This document outlines the Git workflow and commit history structure for the Personal Expense Tracker Backend.

## Commit Message Format

All commits follow this format:

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

- **feat**: A new feature
- **fix**: A bug fix
- **docs**: Documentation only changes
- **style**: Changes that don't affect code meaning (formatting, semicolons, etc.)
- **refactor**: Code change that neither fixes a bug nor adds a feature
- **perf**: Code change that improves performance
- **test**: Adding missing tests or correcting existing tests
- **chore**: Changes to build process, dependencies, or tools

### Scopes

- **config**: Configuration files
- **db**: Database and models
- **middleware**: Middleware implementations
- **routes**: Route definitions
- **controllers**: Controller implementations
- **services**: Service layer
- **utils**: Utility functions
- **types**: TypeScript types and interfaces
- **docs**: Documentation
- **ci**: CI/CD configuration

### Examples

```
feat(models): add User schema with validation hooks
fix(services): handle duplicate email errors correctly
docs(readme): add API documentation
refactor(middleware): consolidate error handling
```

## Recommended Commit History

The following represents an ideal commit history for this project:

### 1. Project Initialization
```
chore(init): initialize project with dependencies and configuration
```

### 2. Configuration
```
feat(config): add environment configuration
feat(config): add database connection setup
```

### 3. Database Layer
```
feat(db): add User schema with validation
feat(db): add Expense schema with relationships
feat(db): add database indexes for performance
```

### 4. Utilities
```
feat(utils): add custom error classes
feat(utils): add response formatting utilities
feat(utils): add input validation schemas
feat(utils): add pagination helpers
```

### 5. Middleware
```
feat(middleware): add security middleware (Helmet, CORS)
feat(middleware): add request logging middleware
feat(middleware): add global error handler
```

### 6. Services
```
feat(services): add UserService with CRUD operations
feat(services): add ExpenseService with calculations
feat(services): add monthly summary aggregation
```

### 7. Controllers
```
feat(controllers): add UserController with endpoints
feat(controllers): add ExpenseController with endpoints
```

### 8. Routes
```
feat(routes): add user routes
feat(routes): add expense routes
feat(routes): add nested user expense routes
```

### 9. Application
```
feat(app): initialize Express server with middleware
feat(app): add health check endpoint
```

### 10. Documentation
```
docs(readme): add comprehensive API documentation
docs(examples): add API testing examples
docs(deployment): add deployment guide
docs(workflow): add Git workflow guide
```

## Git Commands

### Creating Commits

```bash
# Stage all changes
git add .

# Stage specific file
git add src/models/User.ts

# Commit with message
git commit -m "feat(models): add User schema with validation"

# Commit with body
git commit -m "feat(models): add User schema with validation

- Implement email uniqueness validation
- Add pre-save hooks for data consistency
- Create database indexes for performance"
```

### Viewing History

```bash
# View commit log
git log

# View one-line log
git log --oneline

# View log with graph
git log --oneline --graph --all

# View commits for specific file
git log -- src/models/User.ts

# View commit details
git show <commit-hash>
```

### Branching

```bash
# Create feature branch
git checkout -b feat/user-management

# Commit changes
git add .
git commit -m "feat(controllers): add user management endpoints"

# Push to remote
git push origin feat/user-management

# Create pull request (on GitHub)
# Review and merge to main
```

### Rebasing

```bash
# Rebase current branch on main
git rebase main

# Interactive rebase for squashing commits
git rebase -i HEAD~3

# Force push after rebase
git push --force-with-lease origin feat/user-management
```

## Best Practices

### 1. Atomic Commits
- Each commit should represent one logical change
- Should be buildable and testable independently
- Should have clear purpose

### 2. Meaningful Messages
- Use present tense ("add feature" not "added feature")
- Be specific and descriptive
- Reference issues if applicable

### 3. Frequent Commits
- Commit frequently (multiple times per feature)
- Keep commits small and focused
- Push regularly to remote

### 4. Code Review
- Use pull requests for code review
- Request reviews from team members
- Resolve conflicts before merging

### 5. Clean History
- Rebase before merging to avoid merge commits
- Squash related commits if needed
- Keep main branch clean

## Sample Workflow

### 1. Start New Feature

```bash
# Update main branch
git checkout main
git pull origin main

# Create feature branch
git checkout -b feat/monthly-expenses-summary
```

### 2. Implement Feature

```bash
# Make changes and commit regularly
git add src/services/expenseService.ts
git commit -m "feat(services): add monthly expense aggregation"

git add src/controllers/expenseController.ts
git commit -m "feat(controllers): add expense summary endpoint"

git add src/routes/userExpenseRoutes.ts
git commit -m "feat(routes): add summary route to user expenses"
```

### 3. Update & Review

```bash
# Rebase on latest main
git fetch origin
git rebase origin/main

# Force push updated commits
git push --force-with-lease origin feat/monthly-expenses-summary
```

### 4. Create Pull Request

```bash
# Create PR on GitHub
# - Add description of changes
# - Reference related issues
# - Request reviewers
```

### 5. Address Feedback

```bash
# Make requested changes
git add .
git commit -m "refactor(services): improve summary calculation"

# Push updates
git push origin feat/monthly-expenses-summary
```

### 6. Merge to Main

```bash
# Merge after approval
# Use "Squash and merge" if multiple related commits
# Or "Rebase and merge" to preserve commit history

git checkout main
git pull origin main
git merge feat/monthly-expenses-summary
git push origin main

# Delete feature branch
git branch -d feat/monthly-expenses-summary
git push origin --delete feat/monthly-expenses-summary
```

## GitHub Setup

### 1. Create Repository

```bash
# Initialize local repo
git init
git add .
git commit -m "chore(init): initialize project"

# Add remote
git remote add origin https://github.com/yourusername/expense-tracker-backend.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### 2. Configure Branch Protection

On GitHub:
1. Go to Settings > Branches
2. Add rule for `main` branch
3. Require pull request reviews
4. Require status checks to pass
5. Require branches up to date

### 3. Setup CI/CD

Create `.github/workflows/test.yml`:

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
      - run: npm ci
      - run: npm run type-check
      - run: npm run lint
```

## Rewriting History (Use with Caution)

### Ammend Last Commit

```bash
# Make changes
git add .

# Amend commit
git commit --amend

# Force push if already pushed
git push --force-with-lease
```

### Interactive Rebase

```bash
# Rebase last 3 commits
git rebase -i HEAD~3

# Options:
# - pick: use commit
# - reword: change commit message
# - squash: combine with previous
# - fixup: combine without message
```

## Tagging Releases

```bash
# Create version tag
git tag -a v1.0.0 -m "Release version 1.0.0"

# Push tags
git push origin --tags

# View tags
git tag -l
```

## Useful Aliases

Add to `.gitconfig`:

```bash
[alias]
    st = status
    co = checkout
    br = branch
    ci = commit
    lo = log --oneline
    graph = log --oneline --graph --all
    unstage = reset HEAD --
    last = log -1 HEAD
    amend = commit --amend --no-edit
    revert = reset --soft HEAD~1
```

Use:
```bash
git lo                  # instead of git log --oneline
git graph              # instead of git log --oneline --graph --all
git co main            # instead of git checkout main
```

## Troubleshooting

### Undo Last Commit

```bash
# Keep changes
git reset --soft HEAD~1

# Discard changes
git reset --hard HEAD~1
```

### Undo Pushed Commit

```bash
# Revert commit (creates new commit)
git revert <commit-hash>
git push origin main
```

### Fix Wrong Branch

```bash
# Create commit on new branch
git checkout -b correct-branch
git checkout main
git reset --hard HEAD~1  # Remove from main
```

### Recover Deleted Branch

```bash
# Find deleted branch
git reflog

# Recover
git checkout -b recovered-branch <commit-hash>
```

## Team Collaboration

### Code Review Guidelines

1. **Review Process**
   - One approval before merge
   - All checks must pass
   - Address all feedback

2. **Comment Style**
   - Be respectful and constructive
   - Explain reasoning for suggestions
   - Acknowledge good implementations

3. **Conflict Resolution**
   - Discuss conflicts in pull request
   - Avoid long-running branches
   - Rebase frequently

### Merge Strategies

**Squash and Merge**: For small features
```bash
git merge --squash feat/small-feature
```

**Rebase and Merge**: For clean history
```bash
git rebase main
git merge feat/feature-name
```

**Merge Commit**: For significant changes
```bash
git merge --no-ff feat/major-feature
```

## Resources

- [Git Documentation](https://git-scm.com/doc)
- [GitHub Flow Guide](https://guides.github.com/introduction/flow/)
- [Conventional Commits](https://www.conventionalcommits.org/)
- [Git Workflow Comparison](https://www.atlassian.com/git/tutorials/comparing-workflows)
